@extends('app')
@section('content')
   Сторінка контактів
    <a href={{ route('about.page') }}>"Перехід на "Про нас"</a>
@endsection
