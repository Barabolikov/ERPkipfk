@extends('app')
@section('content')
    Сторінка про нас
@endsection
