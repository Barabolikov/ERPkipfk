<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1>Профіль користувача</h1>
                            </div>

                        </div>

                </section>
                <div class="row">
                    <div class="col-md-6 col-xl-6">
                        <div class="card card-primary card-outline">
                            <div class="card-body box-profile">
                                <div class="text-center">
                                    <img class="card-img-top rounded-circle" src="<?php echo e((!empty($adminData->photo))? url('upload/admin_images/'.$adminData->photo)
                                :url('upload/no-image.png')); ?>" alt="" width="50%">
                                </div>

                                <h3 class="profile-username text-center"><?php echo e($adminData->name); ?></h3>

                                <p class="text-muted text-center"><?php echo e($adminData->username); ?></p>

                                <ul class="list-group list-group-unbordered mb-3">
                                    <li class="list-group-item">
                                        <b>Пошта:</b> <a class="float-right"><?php echo e($adminData->email); ?>1,322</a>
                                    </li>

                                </ul>

                                <a href="<?php echo e(route('edit.profile')); ?>" class="btn btn-primary btn-block"><b>Редагувати профіль</b></a>
                            </div>
                            <!-- /.card-body -->
                        </div>


                    </div><!-- end col -->


        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\kipfk\resources\views/admin/admin_profile_view.blade.php ENDPATH**/ ?>