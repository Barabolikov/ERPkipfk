@extends('app')
@section('content')
    Тут буде робочий елемент головної сторінки
@endsection
