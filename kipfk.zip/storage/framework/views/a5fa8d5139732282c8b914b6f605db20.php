   <?php echo $__env->make('admin.body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ========== Left Sidebar Start ========== -->
    <?php echo $__env->make('admin.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Left Sidebar End -->



    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ===assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js=========================================================== -->
  <?php echo $__env->yieldContent('content'); ?>
    <!-- end main content-->
   <?php echo $__env->make('admin.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\kipfk\resources\views/admin/admin_master.blade.php ENDPATH**/ ?>